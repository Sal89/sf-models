from tdx_builder import pack_tdx

# Change this to your filename! 
# Use bpp=4 for 16-color emoticons or bpp=8 for 256-color.
pack_tdx("my_emoticon.png", bpp=4)