from PIL import Image
import swizzle
import helpers

def png_to_tdx(png_path: str, bpp: int = 8):
    img = Image.open(png_path).convert("RGBA")
    width, height = img.size
    
    # 1. Quantize image
    quantized = img.quantize(colors=256 if bpp == 8 else 16)
    pixel_indices = list(quantized.getdata())
    
    # 2. Prepare Palette
    raw_palette = quantized.getpalette() # [R,G,B...]
    # Note: Extracting alpha requires more complex PIL handling, 
    # using 255 (opaque) as default for now
    alpha_channel = [255] * (256 if bpp == 8 else 16)
    interleaved_palette = helpers.pack_palette(raw_palette, alpha_channel)
    
    # 3. Apply Re-Swizzling
    # Based on main.py logic: Pattern 8 = swizzled pixels + swizzled palette
    swizzled_pal = swizzle.reswizzle_palette(interleaved_palette)
    if bpp == 8:
        final_pixels = swizzle.swizzle_i8(width, height, bytes(pixel_indices))
    else:
        final_pixels = swizzle.swizzle_i4(width, height, bytes(pixel_indices))

    # 4. Assemble File
    tdx_data = bytearray(0x5E0 + len(final_pixels)) # Standard 0x8 flag offset
    
    # Header
    tdx_data[0x04:0x06] = width.to_bytes(2, 'little')
    tdx_data[0x06:0x08] = height.to_bytes(2, 'little')
    tdx_data[0x08] = bpp
    tdx_data[0x106] = 0x08 # Swizzle pattern flag
    
    # Data Placement
    tdx_data[0x1E0:0x1E0 + len(swizzled_pal)] = swizzled_pal
    tdx_data[0x5E0:0x5E0 + len(final_pixels)] = final_pixels
    
    with open(png_path.replace(".png", ".tdx"), "wb") as f:
        f.write(tdx_data)