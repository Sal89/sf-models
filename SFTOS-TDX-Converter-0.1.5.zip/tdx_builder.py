import os
from PIL import Image
import swizzle
from helpers import alpha_to_ps2

def pack_tdx(png_path, bpp=8):
    # 1. Load and Quantize PNG
    img = Image.open(png_path).convert("RGBA")
    width, height = img.size
    num_colors = 256 if bpp == 8 else 16
    quantized = img.quantize(colors=num_colors, method=Image.FASTOCTREE)
    pixel_indices = list(quantized.getdata())

    # 2. Extract Palette with Alpha
    raw_pal = quantized.getpalette()

    # BUGFIX: alpha_map non deterministico.
    # L'approccio precedente usava {indice_palette: alpha_pixel}, dove in caso di
    # collisione vinceva l'ultimo pixel incontrato — ordine dipendente dalla
    # quantizzazione, non riproducibile tra esecuzioni diverse.
    # Soluzione: per ogni indice di palette raccogliamo tutti i valori alpha dei
    # pixel che lo usano e ne facciamo la media (deterministica e rappresentativa).
    alpha_pixels = img.getdata()
    alpha_accum = [[] for _ in range(num_colors)]
    for i, idx in enumerate(pixel_indices):
        alpha_accum[idx].append(alpha_pixels[i][3])

    interleaved_pal = bytearray()
    for i in range(num_colors):
        interleaved_pal.extend(raw_pal[i*3 : i*3+3])
        avg_alpha = round(sum(alpha_accum[i]) / len(alpha_accum[i])) if alpha_accum[i] else 255
        interleaved_pal.append(alpha_to_ps2(avg_alpha))  # Scala PNG (0-255) -> PS2 (0-128)

    # 3. Apply Re-Swizzling
    swizzled_pal = swizzle.reswizzle_palette(bytes(interleaved_pal))
    if bpp == 8:
        final_pixels = swizzle.swizzle_i8(width, height, bytes(pixel_indices))
    else:
        final_pixels = swizzle.swizzle_i4(width, height, bytes(pixel_indices))

    # 4. Assemble the Binary Container
    output = bytearray(0x5E0 + len(final_pixels))

    # Header: Dimensions and BPP
    output[0x04:0x06] = width.to_bytes(2, 'little')
    output[0x06:0x08] = height.to_bytes(2, 'little')
    output[0x08] = bpp

    # Swizzle Flag
    output[0x106] = 0x08  # Flag 0x08: Swizzled Pixels + Swizzled Palette

    # Data Placement
    output[0x1E0:0x1E0 + 1024] = swizzled_pal
    output[0x5E0:0x5E0 + len(final_pixels)] = final_pixels

    # 5. Save Output
    out_name = os.path.splitext(png_path)[0] + ".tdx"
    with open(out_name, "wb") as f:
        f.write(output)
    print(f"File created: {out_name}")
