# Pixel unswizzling functions taken from https://github.com/neko68k/rtftool
# Full credit to Neko68k for the algorithms.
# Palette unswizzling function taken from https://github.com/bartlomiejduda/ReverseBox
# Full credit to bartlomiejduda for the algorithm.

def unswizzle_morton(width: int, height: int, data: bytes) -> bytearray:
    """Decodes Morton (Z-Order) swizzled pixels for PS2 Port textures."""
    out = bytearray(len(data))
    for y in range(height):
        for x in range(width):
            mort = 0
            for i in range(12):
                mort |= ((x & (1 << i)) << i) | ((y & (1 << i)) << (i + 1))
            if mort < len(data):
                out[y * width + x] = data[mort]
    return out

def unswizzle_tiled(width: int, height: int, data: bytes) -> bytearray:
    """Decodes PSP-style 8x8 tiled swizzling."""
    out = bytearray(len(data))
    for ty in range(0, height, 8):
        for tx in range(0, width, 8):
            for py in range(8):
                for px in range(8):
                    src_idx = (ty * width) + (tx * 8) + (py * 8) + px
                    dest_idx = ((ty + py) * width) + (tx + px)
                    if src_idx < len(data):
                        out[dest_idx] = data[src_idx]
    return out

def unswizzle_i8(w: int, h: int, in_pixels: bytes) -> bytearray:
    out_pixels = bytearray(w * h)

    for y in range(h):
        for x in range(w):
            block_location = (y & (~0xF)) * w + (x & (~0xF)) * 2
            swap_selector = (((y + 2) >> 2) & 0x1) * 4
            pos_y = (((y & (~3)) >> 1) + (y & 1)) & 0x7
            column_location = pos_y * w * 2 + ((x + swap_selector) & 0x7) * 4

            byte_num = ((y >> 1) & 1) + ((x >> 2) & 2)  # 0,1,2,3

            pixel_idx = (y * w) + x
            out_pixels[pixel_idx] = in_pixels[
                block_location + column_location + byte_num
            ]

    return out_pixels

def unswizzle_i4(w: int, h: int, in_bytes: bytes) -> bytearray:
    out_bytes = bytearray((w * h + 1) // 2)

    for y in range(h):
        for x in range(w):
            page_x = x & (~0x7F)
            page_y = y & (~0x7F)

            pages_horz = (w + 127) // 128
            pages_vert = (h + 127) // 128

            page_number = (page_y // 128) * pages_horz + (page_x // 128)

            page32_y = (page_number // pages_vert) * 32
            page32_x = (page_number % pages_vert) * 64

            page_location = page32_y * h * 2 + page32_x * 4

            loc_x = x & 0x7F
            loc_y = y & 0x7F

            block_location = ((loc_x & (~0x1F)) >> 1) * h + (loc_y & (~0xF)) * 2
            swap_selector = (((y + 2) >> 2) & 0x1) * 4
            pos_y = (((y & (~3)) >> 1) + (y & 1)) & 0x7

            column_location = pos_y * h * 2 + ((x + swap_selector) & 0x7) * 4

            byte_num = (x >> 3) & 3

            entry = in_bytes[
                page_location + block_location + column_location + byte_num
            ]
            entry = (entry >> (((y >> 1) & 0x01) * 4)) & 0x0F

            pixel_idx = (y * w) + x
            out_idx = pixel_idx >> 1

            if (pixel_idx & 1) == 0:
                out_bytes[out_idx] = (out_bytes[out_idx] & 0xF0) | entry
            else:
                out_bytes[out_idx] = (entry << 4) | (out_bytes[out_idx] & 0x0F)

    return out_bytes

def unswizzle_palette(palette_data: bytes) -> bytes:
    bytes_per_palette_pixel: int = 4
    converted_palette_data: bytes = b""

    parts: int = int(len(palette_data) / 32)
    stripes: int = 2
    colors: int = 8
    blocks: int = 2
    index: int = 0

    for part in range(parts):
        for block in range(blocks):
            for stripe in range(stripes):
                for color in range(colors):
                    palette_index: int = (
                        index
                        + part * colors * stripes * blocks
                        + block * colors
                        + stripe * stripes * colors
                        + color
                    )
                    palette_offset: int = palette_index * bytes_per_palette_pixel
                    palette_entry = palette_data[palette_offset: palette_offset + bytes_per_palette_pixel]
                    converted_palette_data += palette_entry

    return converted_palette_data

def swizzle_i8(w: int, h: int, linear_pixels: bytes) -> bytearray:
    """Rearranges linear pixels into PS2 8bpp swizzled format."""
    swizzled_pixels = bytearray(w * h)
    for y in range(h):
        for x in range(w):
            block_location = (y & (~0xF)) * w + (x & (~0xF)) * 2
            swap_selector = (((y + 2) >> 2) & 0x1) * 4
            pos_y = (((y & (~3)) >> 1) + (y & 1)) & 0x7
            column_location = pos_y * w * 2 + ((x + swap_selector) & 0x7) * 4
            byte_num = ((y >> 1) & 1) + ((x >> 2) & 2)
            swizzled_pixels[block_location + column_location + byte_num] = linear_pixels[y * w + x]
    return swizzled_pixels

def swizzle_i4(w: int, h: int, linear_pixels: bytes) -> bytearray:
    """Rearranges linear pixels into PS2 4bpp swizzled format."""
    swizzled_bytes = bytearray((w * h + 1) // 2)
    pages_horz = (w + 127) // 128
    pages_vert = (h + 127) // 128
    for y in range(h):
        for x in range(w):
            page_x, page_y = x & (~0x7F), y & (~0x7F)
            page_number = (page_y // 128) * pages_horz + (page_x // 128)
            page32_y, page32_x = (page_number // pages_vert) * 32, (page_number % pages_vert) * 64
            page_location = page32_y * h * 2 + page32_x * 4
            loc_x, loc_y = x & 0x7F, y & 0x7F
            block_location = ((loc_x & (~0x1F)) >> 1) * h + (loc_y & (~0xF)) * 2
            swap_selector = (((y + 2) >> 2) & 0x1) * 4
            pos_y = (((y & (~3)) >> 1) + (y & 1)) & 0x7
            column_location = pos_y * h * 2 + ((x + swap_selector) & 0x7) * 4
            byte_num = (x >> 3) & 3
            pixel_val = linear_pixels[y * w + x] & 0x0F
            shift = ((y >> 1) & 0x01) * 4
            mask = 0x0F << shift
            swizzled_bytes[page_location + block_location + column_location + byte_num] = \
                (swizzled_bytes[page_location + block_location + column_location + byte_num] & ~mask) | (pixel_val << shift)
    return swizzled_bytes

def reswizzle_palette(linear_palette: bytes) -> bytes:
    """Inversa esatta di unswizzle_palette.

    Invece di replicare manualmente la logica dei loop (approccio precedente,
    che produceva una seconda unswizzle invece di un'inversione), costruiamo
    la permutazione che unswizzle applica agli indici e la invertiamo.

    perm[i] = j significa: unswizzle legge dall'entry j e scrive in i.
    Quindi reswizzle deve fare l'opposto: leggere da i e scrivere in j.
    """
    n_colors = len(linear_palette) // 4

    # Costruisci la permutazione da unswizzle usando una palette marker
    marker = bytearray(n_colors * 4)
    for i in range(n_colors):
        marker[i*4]   = i % 256
        marker[i*4+1] = i // 256
    unswizzled_marker = unswizzle_palette(bytes(marker))
    perm = [unswizzled_marker[i*4] + unswizzled_marker[i*4+1] * 256
            for i in range(n_colors)]

    # Applica la permutazione inversa
    reswizzled = bytearray(len(linear_palette))
    for i in range(n_colors):
        j = perm[i]
        reswizzled[j*4:j*4+4] = linear_palette[i*4:i*4+4]
    return bytes(reswizzled)