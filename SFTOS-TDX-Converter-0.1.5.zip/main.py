import math
import os
from PIL import Image
from io import open
from tkinter import filedialog
import helpers
import logger_utils
import swizzle

# ── PS2/Dark Mirror 4bpp unswizzle (da ReverseBox, integrato senza dipendenze) ─
def _ps2_unswizzle4_block(input_block_data):
    unswizzle_lut = [
        0,8,16,24,32,40,48,56, 2,10,18,26,34,42,50,58,
        4,12,20,28,36,44,52,60, 6,14,22,30,38,46,54,62,
        64,72,80,88,96,104,112,120, 66,74,82,90,98,106,114,122,
        68,76,84,92,100,108,116,124, 70,78,86,94,102,110,118,126,
        33,41,49,57,1,9,17,25, 35,43,51,59,3,11,19,27,
        37,45,53,61,5,13,21,29, 39,47,55,63,7,15,23,31,
        97,105,113,121,65,73,81,89, 99,107,115,123,67,75,83,91,
        101,109,117,125,69,77,85,93, 103,111,119,127,71,79,87,95,
        32,40,48,56,0,8,16,24, 34,42,50,58,2,10,18,26,
        36,44,52,60,4,12,20,28, 38,46,54,62,6,14,22,30,
        96,104,112,120,64,72,80,88, 98,106,114,122,66,74,82,90,
        100,108,116,124,68,76,84,92, 102,110,118,126,70,78,86,94,
        1,9,17,25,33,41,49,57, 3,11,19,27,35,43,51,59,
        5,13,21,29,37,45,53,61, 7,15,23,31,39,47,55,63,
        65,73,81,89,97,105,113,121, 67,75,83,91,99,107,115,123,
        69,77,85,93,101,109,117,125, 71,79,87,95,103,111,119,127
    ]
    out = bytearray(256)
    index1 = 0
    p_in = 0
    for k in range(4):
        index0 = (k % 2) * 128
        for i in range(16):
            for j in range(4):
                c_out = 0
                i0 = unswizzle_lut[index0]; index0 += 1
                c_in = (input_block_data[p_in + i0//2] >> ((i0 & 1)*4)) & 0xF
                c_out |= c_in
                i0 = unswizzle_lut[index0]; index0 += 1
                c_in = (input_block_data[p_in + i0//2] >> ((i0 & 1)*4)) & 0xF
                c_out |= (c_in << 4) & 0xF0
                out[index1] = c_out
                index1 += 1
        p_in += 64
    return bytes(out)

def _ps2_unswizzle4_page(width, height, input_page):
    block_table4  = [0,2,8,10,1,3,9,11,4,6,12,14,5,7,13,15,
                     16,18,24,26,17,19,25,27,20,22,28,30,21,23,29,31]
    block_table32 = [0,1,4,5,16,17,20,21,2,3,6,7,18,19,22,23,
                     8,9,12,13,24,25,28,29,10,11,14,15,26,27,30,31]
    PSMCT32_PAGE_WIDTH = 64; PSMCT32_PAGE_HEIGHT = 32
    PSMT4_BLOCK_HEIGHT = 16

    out = bytearray(PSMCT32_PAGE_WIDTH * 4 * PSMCT32_PAGE_HEIGHT)
    index32_h = [0]*32; index32_v = [0]*32
    index0 = 0
    for i in range(4):
        for j in range(8):
            index1 = block_table32[index0]
            index32_h[index1] = j; index32_v[index1] = i
            index0 += 1

    n_width = width // 32; n_height = height // 16
    input_line  = 256; output_line = 64

    for i in range(n_height):
        for j in range(n_width):
            in_block = block_table4[i * n_width + j]
            po0 = bytearray(256)
            po1_off = 8 * index32_v[in_block] * input_line + index32_h[in_block] * 32
            for k in range(8):
                po0[k*32:(k+1)*32] = input_page[po1_off + k*input_line : po1_off + k*input_line + 32]
            out_block = _ps2_unswizzle4_block(po0)
            for k in range(PSMT4_BLOCK_HEIGHT):
                start = (16*i*output_line) + j*16 + k*output_line
                out[start:start+16] = out_block[k*16:k*16+16]
    return bytes(out)

def _ps2_unswizzle4(input_data, img_width, img_height):
    PSMT4_PAGE_WIDTH = 128; PSMT4_PAGE_HEIGHT = 128
    PSMCT32_PAGE_WIDTH = 64; PSMCT32_PAGE_HEIGHT = 32

    out = bytearray(len(input_data))
    n_page_w = (img_width  - 1) // PSMT4_PAGE_WIDTH  + 1
    n_page_h = (img_height - 1) // PSMT4_PAGE_HEIGHT + 1
    n_page4_width_byte   = PSMT4_PAGE_WIDTH // 2
    n_page32_width_byte  = PSMCT32_PAGE_WIDTH * 4

    if n_page_h == 1:
        n_input_width_byte = img_height * 2
        n_output_height    = img_height
    else:
        n_input_width_byte = n_page32_width_byte
        n_output_height    = PSMT4_PAGE_HEIGHT

    if n_page_w == 1:
        n_input_height     = img_width // 4
        n_output_width_byte = img_width // 2
    else:
        n_input_height      = PSMCT32_PAGE_HEIGHT
        n_output_width_byte = n_page4_width_byte

    for i in range(n_page_h):
        for j in range(n_page_w):
            po0_off = (n_input_width_byte * n_input_height) * n_page_w * i + n_input_width_byte * j
            po0 = input_data[po0_off:]
            input_page = bytearray(PSMT4_PAGE_WIDTH//2 * PSMT4_PAGE_HEIGHT)
            for k in range(n_input_height):
                src = k * n_input_width_byte * n_page_w
                dst = k * n_page32_width_byte
                input_page[dst:dst+n_input_width_byte] = po0[src:src+n_input_width_byte]
            output_page = _ps2_unswizzle4_page(PSMT4_PAGE_WIDTH, PSMT4_PAGE_HEIGHT, input_page)
            pi0_off = (n_output_width_byte * n_output_height) * n_page_w * i + n_output_width_byte * j
            for k in range(n_output_height):
                src = k * n_page4_width_byte
                dst = pi0_off + k * n_output_width_byte * n_page_w
                out[dst:dst+n_output_width_byte] = output_page[src:src+n_output_width_byte]
    return bytes(out)

images_failed_to_convert = {}

# ── Algoritmi swizzle ─────────────────────────────────────────────────────────

def _unswizzle_i4(w, h, in_bytes):
    out_bytes = bytearray((w * h + 1) // 2)
    for y in range(h):
        for x in range(w):
            page_x = x & (~0x7F)
            page_y = y & (~0x7F)
            pages_horz = (w + 127) // 128
            pages_vert = (h + 127) // 128
            page_number = (page_y // 128) * pages_horz + (page_x // 128)
            page32_y = (page_number // pages_vert) * 32
            page32_x = (page_number % pages_vert) * 64
            page_location = page32_y * h * 2 + page32_x * 4
            loc_x = x & 0x7F
            loc_y = y & 0x7F
            block_location = ((loc_x & (~0x1F)) >> 1) * h + (loc_y & (~0xF)) * 2
            swap_selector = (((y + 2) >> 2) & 0x1) * 4
            pos_y = (((y & (~3)) >> 1) + (y & 1)) & 0x7
            column_location = pos_y * h * 2 + ((x + swap_selector) & 0x7) * 4
            byte_num = (x >> 3) & 3
            entry = in_bytes[page_location + block_location + column_location + byte_num]
            entry = (entry >> (((y >> 1) & 0x01) * 4)) & 0x0F
            pixel_idx = (y * w) + x
            out_idx = pixel_idx >> 1
            if (pixel_idx & 1) == 0:
                out_bytes[out_idx] = (out_bytes[out_idx] & 0xF0) | entry
            else:
                out_bytes[out_idx] = (entry << 4) | (out_bytes[out_idx] & 0x0F)
    return out_bytes

# ── Conversori per BPP ────────────────────────────────────────────────────────

def _convert_32bpp_psp(file_data, width, height):
    """PSP 32bpp: pixel a 0x60, PSP unswizzle con stride w*4.
    VERIFICATO: TRIANGLE1 (imageFlags=0x4006)"""
    expected = width * height * 4
    raw = bytes(file_data[0x60:0x60+expected])
    if len(raw) < expected:
        return None
    unswizzled = _unswizzle_psp_packed(width * 4, height, raw)
    rgba = bytearray()
    for i in range(width * height):
        r,g,b,a = unswizzled[i*4],unswizzled[i*4+1],unswizzled[i*4+2],unswizzled[i*4+3]
        rgba.extend([r, g, b, min(255, round(a * 255 / 128))])
    return Image.frombytes("RGBA", (width, height), bytes(rgba))

def _convert_32bpp(file_data, width, height, pattern):
    """32bpp RGBA diretto. Pattern ignorato. Pixel a (filesize - w*h*4).
    VERIFICATO: BRIGHTWHITE (0xFF), IVAN (0x00), THER (0xED)"""
    expected = width * height * 4
    offset = len(file_data) - expected
    if offset < 0:
        return None
    raw = file_data[offset:offset+expected]
    rgba = bytearray()
    for i in range(width * height):
        r,g,b,a = raw[i*4], raw[i*4+1], raw[i*4+2], raw[i*4+3]
        rgba.extend([r, g, b, min(255, round(a * 255 / 128))])
    return Image.frombytes("RGBA", (width, height), bytes(rgba))

def _convert_24bpp(file_data, width, height, pattern):
    """24bpp RGB diretto. Pattern ignorato. Pixel a (filesize - w*h*3).
    VERIFICATO: SHIR_SOK_BLUE (0x91), BHOLE_CONC1 (0x00)"""
    expected = width * height * 3
    offset = len(file_data) - expected
    if offset < 0:
        return None
    raw = file_data[offset:offset+expected]
    if len(raw) < expected:
        return None
    return Image.frombytes("RGB", (width, height), bytes(raw))

def _unswizzle_psp_packed(w_bytes, h, data_in):
    """PSP unswizzle su dati packed (byte-width = w//2 per 4bpp).
    VERIFICATO: BODY_MKIT_P (PSP 4bpp imageFlags=0x4001)"""
    out = bytearray(len(data_in))
    src = 0
    for yb in range(h >> 3):
        for xb in range(w_bytes >> 4):
            for row in range(8):
                dst = (yb*8+row)*w_bytes + xb*16
                for col in range(16):
                    if src < len(data_in) and dst+col < len(out):
                        out[dst+col] = data_in[src]
                    src += 1
    return out

def _convert_4bpp_psp_raw(file_data, width, height):
    """PSP 4bpp imageFlags=0x4005: palette lineare a 0x60, pixel raw nibble low a 0xA0.
    VERIFICATO: BRIGHTWHITE (16x16)"""
    pal_raw = file_data[0x60:0x60+64] + b'\x00'*(1024-64)
    pix_packed = bytes(file_data[0xA0:0xA0+(width*height)//2])
    if len(pix_packed) < (width*height)//2:
        pix_packed += b'\x00'*((width*height)//2 - len(pix_packed))

    pix = bytearray(n for b in pix_packed for n in [b&0xF, (b>>4)&0xF])[:width*height]

    rgb_palette = bytearray()
    alpha_palette = []
    for i in range(256):
        r,g,b,a = pal_raw[i*4],pal_raw[i*4+1],pal_raw[i*4+2],pal_raw[i*4+3]
        rgb_palette.extend([r,g,b])
        alpha_palette.append(min(255, round(a*255/128)))

    indexed = Image.new("P", (width, height))
    indexed.putdata(pix)
    indexed.putpalette(rgb_palette)
    conv = indexed.convert("RGBA")
    r, g, b, _ = conv.split()
    alpha_ch = Image.frombytes("L", (width, height), bytes(alpha_palette[idx] for idx in pix))
    return Image.merge("RGBA", (r, g, b, alpha_ch))

def _convert_4bpp_psp_4001(file_data, width, height):
    """PSP 4bpp imageFlags=0x4001: palette lineare 16 entry a 0x60, pixel a 0xA0.
    PSP unswizzle sul packed + nibble low.
    VERIFICATO: BODY_MKIT_P"""
    pal_raw = file_data[0x60:0x60+64] + b'\x00'*(1024-64)
    pix_packed = bytes(file_data[0xA0:0xA0+(width*height)//2])
    if len(pix_packed) < (width*height)//2:
        pix_packed += b'\x00'*((width*height)//2 - len(pix_packed))

    unswizzled = _unswizzle_psp_packed(width//2, height, pix_packed)
    pix = bytearray(n for b in unswizzled for n in [b&0xF, (b>>4)&0xF])[:width*height]

    rgb_palette = bytearray()
    alpha_palette = []
    for i in range(256):
        r,g,b,a = pal_raw[i*4],pal_raw[i*4+1],pal_raw[i*4+2],pal_raw[i*4+3]
        rgb_palette.extend([r,g,b])
        alpha_palette.append(min(255, round(a*255/128)))

    indexed = Image.new("P", (width, height))
    indexed.putdata(pix)
    indexed.putpalette(rgb_palette)
    conv = indexed.convert("RGBA")
    r, g, b, _ = conv.split()
    alpha_ch = Image.frombytes("L", (width, height), bytes(alpha_palette[idx] for idx in pix))
    return Image.merge("RGBA", (r, g, b, alpha_ch))
    """PSP unswizzle per 8bpp: blocchi 16x8 byte.
    VERIFICATO: SHADOW (64x64), HKONGCONCEPT (512x256) — imageFlags=0x4001"""
    out = bytearray(w * h)
    src = 0
    for yb in range(h >> 3):
        for xb in range(w >> 4):
            for row in range(8):
                dst = (yb*8 + row) * w + xb*16
                for col in range(16):
                    if src < len(data_in) and dst+col < len(out):
                        out[dst+col] = data_in[src]
                    src += 1
    return out

def _convert_8bpp_4001(file_data, width, height):
    """imageFlags=0x4001: palette lineare a 0x60, pixel PSP-unswizzled a 0x460.
    VERIFICATO: SHADOW (64x64), HKONGCONCEPT_02 (512x256)"""
    pal_raw = file_data[0x60:0x60+1024]
    if len(pal_raw) < 1024:
        return None

    rgb_palette = bytearray()
    alpha_palette = []
    for i in range(256):
        r,g,b,a = pal_raw[i*4], pal_raw[i*4+1], pal_raw[i*4+2], pal_raw[i*4+3]
        rgb_palette.extend([r,g,b])
        alpha_palette.append(min(255, round(a * 255 / 128)))

    pixel_data = bytearray(file_data[0x460:0x460+width*height])
    if len(pixel_data) < width*height:
        pixel_data.extend(b'\x00' * (width*height - len(pixel_data)))

    pixel_data = _unswizzle_psp_packed(width, height, pixel_data)

    indexed = Image.new("P", (width, height))
    indexed.putdata(pixel_data)
    indexed.putpalette(rgb_palette)
    conv = indexed.convert("RGBA")
    r, g, b, _ = conv.split()
    alpha_data = bytes(alpha_palette[idx] for idx in pixel_data)
    alpha_ch = Image.frombytes("L", (width, height), alpha_data)
    return Image.merge("RGBA", (r, g, b, alpha_ch))

def _convert_8bpp(file_data, width, height, pattern):
    """8bpp indicizzato. Palette unswizzlata. Pixel unswizzle_i8.
    VERIFICATO: pattern 0x01 (BEAR_DMIT), 0x02 (SFO_LOGO), 0x08 (vari)"""
    if pattern == 0x08:
        pal_offset, pix_offset = 0x1E0, 0x5E0
    elif pattern in (0x01, 0x02, 0x04):
        # 0x04 VERIFICATO: LOBBY_BACKGROUND, FILMSTRIP — identico a 0x02
        pal_offset, pix_offset = 0x160, 0x560
    else:
        return None

    raw_palette = file_data[pal_offset:pal_offset+1024]
    if len(raw_palette) < 1024:
        return None
    palette = swizzle.unswizzle_palette(raw_palette)

    rgb_palette = bytearray()
    alpha_palette = []
    for i in range(256):
        r,g,b,a = palette[i*4], palette[i*4+1], palette[i*4+2], palette[i*4+3]
        rgb_palette.extend([r,g,b])
        alpha_palette.append(min(255, round(a * 255 / 128)))

    pixel_data = bytearray(file_data[pix_offset:pix_offset+width*height])
    if len(pixel_data) < width * height:
        pixel_data.extend(b'\x00' * (width * height - len(pixel_data)))

    if width >= 16 and height >= 16:
        try:
            pixel_data = swizzle.unswizzle_i8(width, height, pixel_data)
        except Exception as e:
            log.error(f'unswizzle_i8 failed: {e}')
            return None

    indexed = Image.new("P", (width, height))
    indexed.putdata(pixel_data)
    indexed.putpalette(rgb_palette)
    conv = indexed.convert("RGBA")
    r, g, b, _ = conv.split()
    alpha_data = bytes(alpha_palette[idx] for idx in indexed.get_flattened_data())
    alpha_ch = Image.frombytes("L", (width, height), alpha_data)
    return Image.merge("RGBA", (r, g, b, alpha_ch))

def _convert_4bpp(file_data, width, height, pattern, is_dark_mirror=False):
    """4bpp indicizzato.
    Dark Mirror: palette lineare 16 entry a 0x160, pixel a 0x1A0, unswizzle_i4 + nibble low
        per qualsiasi pattern — VERIFICATO: NW_REFIN_D2_DOOR (0x01), LOADINGICON_IPCA (0x02)
    OS pattern 0x01, 0x04 — palette lineare, unswizzle_i4 + nibble low — VERIFICATO: ARROW, SCEA
    OS pattern 0x02, 0x08 — palette unswizzlata, nibble low + rimapping PS2 — VERIFICATO: SMAW, HEALTHDROP"""
    if is_dark_mirror:
        pal_raw = file_data[0x160:0x160+64] + b'\x00' * (1024 - 64)
        pix_offset = 0x1A0
        palette = pal_raw
    else:
        if pattern == 0x08:
            pal_offset, pix_offset = 0x1E0, 0x5E0
        elif pattern in (0x01, 0x02, 0x04):
            pal_offset, pix_offset = 0x160, 0x560
        else:
            return None
        raw_palette = file_data[pal_offset:pal_offset+1024]
        if len(raw_palette) < 1024:
            return None
        if pattern in (0x01, 0x04):
            palette = raw_palette
        else:
            palette = swizzle.unswizzle_palette(raw_palette)

    rgb_palette = bytearray()
    alpha_palette = []
    for i in range(256):
        r,g,b,a = palette[i*4], palette[i*4+1], palette[i*4+2], palette[i*4+3]
        rgb_palette.extend([r,g,b])
        alpha_palette.append(min(255, round(a * 255 / 128)))

    pixel_packed = file_data[pix_offset:pix_offset+(width*height)//2]
    expected_packed = (width * height) // 2
    if len(pixel_packed) < expected_packed:
        pixel_packed = pixel_packed + b'\x00' * (expected_packed - len(pixel_packed))
        log.warning(f'4bpp: pixel insufficienti, padding con zeri')

    if is_dark_mirror or pattern in (0x01, 0x04):
        # Dark Mirror: _ps2_unswizzle4 + nibble low — VERIFICATO: ONLINE_GLOBE
        # OS 0x01/0x04: unswizzle_i4 + nibble low — VERIFICATO: ARROW, SCEA
        if is_dark_mirror:
            # width >= height*2: raw nibble low
            #   VERIFICATO: MBAR (128x32), BLUR2 (128x64), BONUS (64x16)
            # altrimenti: _ps2_unswizzle4 + nibble low
            #   VERIFICATO: GLOBE (512x256), DOOR (128x128), LOADING (256x256),
            #               DPAD (64x64), XBTN (32x32), DMLOGO (256x128), SMUDGE (64x64)
            try:
                if width > height * 2 or (width == height * 2 and width <= 128):
                    pixel_data = bytearray(n for b in pixel_packed for n in [b & 0x0F, (b >> 4) & 0x0F])
                else:
                    result = _ps2_unswizzle4(pixel_packed, width, height)
                    pixel_data = bytearray(n for b in result for n in [b & 0x0F, (b >> 4) & 0x0F])
                pixel_data = pixel_data[:width * height]
            except Exception as e:
                log.error(f'Dark Mirror 4bpp failed: {e}')
                return None
        else:
            try:
                pixel_i4 = _unswizzle_i4(width, height, pixel_packed)
            except Exception as e:
                log.error(f'unswizzle_i4 failed: {e}')
                return None
            pixel_data = bytearray(n for b in pixel_i4 for n in [b & 0x0F, (b >> 4) & 0x0F])
            pixel_data = pixel_data[:width * height]
    else:
        # nibble low + rimapping PS2
        expanded = bytearray(n for b in pixel_packed for n in [b & 0x0F, (b >> 4) & 0x0F])
        pixel_data = bytearray((idx & 0x07) | ((idx & 0x08) << 1) for idx in expanded)
        pixel_data = pixel_data[:width * height]

    indexed = Image.new("P", (width, height))
    indexed.putdata(pixel_data)
    indexed.putpalette(rgb_palette)
    conv = indexed.convert("RGBA")
    r, g, b, _ = conv.split()
    alpha_data = bytes(alpha_palette[idx] for idx in indexed.get_flattened_data())
    alpha_ch = Image.frombytes("L", (width, height), alpha_data)
    return Image.merge("RGBA", (r, g, b, alpha_ch))

# ── Dispatcher principale ─────────────────────────────────────────────────────

def convert_texture(tdx_file: str) -> Image.Image | None:
    with open(tdx_file, mode='rb') as f:
        file_data = f.read()

    if len(file_data) < 0x61:
        images_failed_to_convert[tdx_file] = f'File troppo corto ({len(file_data)} byte)'
        log.warning(f'Skip: {tdx_file} (file troppo corto)')
        return None

    version = int.from_bytes(file_data[0x00:0x02], 'little')
    #if version != 5:
    #    images_failed_to_convert[tdx_file] = f'Versione header non supportata ({version})'
    #    log.warning(f'Skip: {tdx_file} (versione {version}, attesa 5)')
    #    return None

    width   = int.from_bytes(file_data[0x04:0x06], 'little')
    height  = int.from_bytes(file_data[0x06:0x08], 'little')
    bpp     = file_data[0x08]
    pattern = file_data[0x106] if len(file_data) > 0x106 else 0
    
    # --- AGGIUNGI QUESTA RIGA PER RISOLVERE IL PROBLEMA ---
    image_flags = int.from_bytes(file_data[0x02:0x04], 'little')

    # Rileva formato: Omega Strain (0x03=0x00) vs Dark Mirror/Logan's Shadow (0x03=0x20)
    is_dark_mirror = (file_data[0x03] == 0x20)

    log.debug(f'{tdx_file}: {width}x{height}, {bpp}bpp, pattern 0x{pattern:02X}, dark_mirror={is_dark_mirror}, image_flags=0x{image_flags:04X}')

    if width == 0 or height == 0:
        images_failed_to_convert[tdx_file] = f'Invalid dimensions ({width}x{height})'
        return None

    if bpp == 32:
        if image_flags & 0x4000:
            # PSP 32bpp: pixel a 0x60, PSP unswizzle con stride w*4
            # VERIFICATO: TRIANGLE1 (0x4006)
            result = _convert_32bpp_psp(file_data, width, height)
        else:
            result = _convert_32bpp(file_data, width, height, pattern)
    elif bpp == 24:
        result = _convert_24bpp(file_data, width, height, pattern)
    elif bpp == 8:
        if image_flags & 0x4000:
            # PSP format: palette lineare a 0x60, pixel PSP-unswizzled a 0x460
            # VERIFICATO: 0x4001 (SHADOW, HKONGCONCEPT)
            result = _convert_8bpp_4001(file_data, width, height)
        else:
            result = _convert_8bpp(file_data, width, height, pattern)
    elif bpp == 4:
        if image_flags & 0x4000:
            # PSP format: palette lineare a 0x60, pixel a 0xA0
            # imageDstSize (0x0E) >= 0x200: PSP unswizzle packed + nibble low
            # imageDstSize (0x0E) < 0x200:  raw nibble low (texture troppo piccola)
            # VERIFICATO: NV_OFF (0x4005, dstSize=0x800) -> PSP
            #             BRIGHTWHITE (0x4005, dstSize=0x080) -> raw
            img_dst_size = int.from_bytes(file_data[0x0E:0x10], 'little')
            if img_dst_size >= 0x200:
                result = _convert_4bpp_psp_4001(file_data, width, height)
            else:
                result = _convert_4bpp_psp_raw(file_data, width, height)
        else:
            result = _convert_4bpp(file_data, width, height, pattern, is_dark_mirror)
    else:
        images_failed_to_convert[tdx_file] = f'Unsupported BPP ({bpp})'
        log.warning(f'Unsupported BPP {bpp}: {tdx_file}')
        return None

    if result is None:
        images_failed_to_convert[tdx_file] = f'Conversion failed ({bpp}bpp, pattern 0x{pattern:02X})'
        log.warning(f'Conversion failed: {tdx_file}')

    return result

# ── Loop principale ───────────────────────────────────────────────────────────

def run_conversion():
    images_failed_to_convert.clear()

    if helpers.get_folder_mode():
        folder = filedialog.askdirectory(title='Seleziona cartella TDX')
        if not folder:
            return
        files = helpers.scan_folders(folder)
    else:
        files = filedialog.askopenfilenames(
            title='Seleziona file TDX',
            filetypes=[('TDX files', '*.tdx')]
        )

    if not files:
        log.warning('Nessun file selezionato.')
        return

    counter = 0
    skipped = 0
    for tdx_file in files:
        image = convert_texture(tdx_file)
        if not image:
            skipped += 1
            continue
        if helpers.get_save_option():
            image.save(f'{tdx_file[:-4]}.png', 'PNG')
            log.debug(f'Salvato: {tdx_file}')
        else:
            image.show()
        counter += 1

    log.info(f'Completato: {counter} convertiti, {skipped} skippati')
    if images_failed_to_convert:
        log.warning('File con errori:')
        for f, err in images_failed_to_convert.items():
            log.warning(f'  {f}: {err}')
        if logger_utils.debug_mode:
            logger_utils.dump_failed_conversions(images_failed_to_convert)


# --- Main ---
import sys

log = logger_utils.instantiate_logger()
log.debug('SFTOS TDX Converter ready.')

# Supporto drag & drop — se viene passata una cartella come argomento, la usa direttamente
if len(sys.argv) > 1:
    folder = ' '.join(sys.argv[1:]).strip('"').strip("'")
    if os.path.isdir(folder):
        log.info(f'Cartella ricevuta: {folder}')
        files = helpers.scan_folders(folder)
        counter = 0
        skipped = 0
        for tdx_file in files:
            image = convert_texture(tdx_file)
            if not image:
                skipped += 1
                continue
            image.save(f'{tdx_file[:-4]}.png', 'PNG')
            log.debug(f'Salvato: {tdx_file}')
            counter += 1
        log.info(f'Completato: {counter} convertiti, {skipped} skippati')
        if images_failed_to_convert:
            log.warning('File con errori:')
            for f, err in images_failed_to_convert.items():
                log.warning(f'  {f}: {err}')
            if logger_utils.debug_mode:
                logger_utils.dump_failed_conversions(images_failed_to_convert)
    else:
        log.error(f'Percorso non valido: {folder}')
else:
    while True:
        try:
            cmd = input('\nDroppa una cartella o premi INVIO per il dialogo, "exit" per uscire: ').strip().strip('"').strip("'")
        except (EOFError, KeyboardInterrupt):
            break
        if cmd.lower() == 'exit':
            break
        elif os.path.isdir(cmd):
            # Cartella droppata direttamente nel terminale
            images_failed_to_convert.clear()
            files = helpers.scan_folders(cmd)
            if not files:
                log.warning('Nessun file TDX trovato.')
                continue
            counter = 0
            skipped = 0
            for tdx_file in files:
                image = convert_texture(tdx_file)
                if not image:
                    skipped += 1
                    continue
                if helpers.get_save_option():
                    image.save(f'{tdx_file[:-4]}.png', 'PNG')
                    log.debug(f'Salvato: {tdx_file}')
                else:
                    image.show()
                counter += 1
            log.info(f'Completato: {counter} convertiti, {skipped} skippati')
            if images_failed_to_convert:
                log.warning('File con errori:')
                for f, err in images_failed_to_convert.items():
                    log.warning(f'  {f}: {err}')
                if logger_utils.debug_mode:
                    logger_utils.dump_failed_conversions(images_failed_to_convert)
        else:
            # Nessun input — apri dialogo file
            run_conversion()

log.debug('Tool chiuso.')