"""
SFTOS / Dark Mirror / Logan's Shadow / PSP TDX Tool
Uso:
  - Trascina uno o più file .TDX  -> converte in .PNG nella stessa cartella
  - Trascina uno o più file .PNG  -> cerca il .TDX originale e lo aggiorna
  - Trascina una cartella         -> applica un'operazione batch a tutti i file con rinomina e cartella di output
  - Lancia senza argomenti        -> loop interattivo con drag&drop nel terminale
"""

import os
import sys
import re
from PIL import Image
from tkinter import filedialog

# ── Algoritmi swizzle (Invariati) ─────────────────────────────────────────────
def _unswizzle_i8(w, h, data):
    out = bytearray(w * h)
    for y in range(h):
        for x in range(w):
            bl = (y & (~0xF)) * w + (x & (~0xF)) * 2
            ss = (((y + 2) >> 2) & 1) * 4
            py = (((y & (~3)) >> 1) + (y & 1)) & 7
            cl = py * w * 2 + ((x + ss) & 7) * 4
            bn = ((y >> 1) & 1) + ((x >> 2) & 2)
            out[y * w + x] = data[bl + cl + bn]
    return out

def _swizzle_i8(w, h, linear):
    out = bytearray(w * h)
    for y in range(h):
        for x in range(w):
            bl = (y & (~0xF)) * w + (x & (~0xF)) * 2
            ss = (((y + 2) >> 2) & 1) * 4
            py = (((y & (~3)) >> 1) + (y & 1)) & 7
            cl = py * w * 2 + ((x + ss) & 7) * 4
            bn = ((y >> 1) & 1) + ((x >> 2) & 2)
            dst = bl + cl + bn
            src = y * w + x
            if dst < len(out) and src < len(linear):
                out[dst] = linear[src]
    return out

def _unswizzle_i4(w, h, in_bytes):
    out = bytearray((w * h + 1) // 2)
    for y in range(h):
        for x in range(w):
            px = x & (~0x7F); py2 = y & (~0x7F)
            ph = (w + 127) // 128; pv = (h + 127) // 128
            pn = (py2 // 128) * ph + (px // 128)
            p32y = (pn // pv) * 32; p32x = (pn % pv) * 64
            pl = p32y * h * 2 + p32x * 4
            lx = x & 0x7F; ly = y & 0x7F
            bl = ((lx & (~0x1F)) >> 1) * h + (ly & (~0xF)) * 2
            ss = (((y + 2) >> 2) & 1) * 4
            pos_y = (((y & (~3)) >> 1) + (y & 1)) & 7
            cl = pos_y * h * 2 + ((x + ss) & 7) * 4
            bn = (x >> 3) & 3
            try: entry = in_bytes[pl + bl + cl + bn]
            except: entry = 0
            entry = (entry >> (((y >> 1) & 1) * 4)) & 0xF
            pi = y * w + x; oi = pi >> 1
            if pi & 1 == 0: out[oi] = (out[oi] & 0xF0) | entry
            else:            out[oi] = (entry << 4) | (out[oi] & 0x0F)
    return out

def _swizzle_i4(w, h, indices):
    out = bytearray((w * h + 1) // 2)
    for y in range(h):
        for x in range(w):
            px = x & (~0x7F); py2 = y & (~0x7F)
            ph = (w + 127) // 128; pv = (h + 127) // 128
            pn = (py2 // 128) * ph + (px // 128)
            p32y = (pn // pv) * 32; p32x = (pn % pv) * 64
            pl = p32y * h * 2 + p32x * 4
            lx = x & 0x7F; ly = y & 0x7F
            bl = ((lx & (~0x1F)) >> 1) * h + (ly & (~0xF)) * 2
            ss = (((y + 2) >> 2) & 1) * 4
            pos_y = (((y & (~3)) >> 1) + (y & 1)) & 7
            cl = pos_y * h * 2 + ((x + ss) & 7) * 4
            bn = (x >> 3) & 3
            nibble_pos = (y >> 1) & 1
            byte_idx = pl + bl + cl + bn
            if byte_idx < len(out):
                entry = indices[y * w + x] & 0xF
                if nibble_pos == 0:
                    out[byte_idx] = (out[byte_idx] & 0xF0) | entry
                else:
                    out[byte_idx] = (out[byte_idx] & 0x0F) | (entry << 4)
    return out

def _unswizzle_palette(p):
    out = b""
    parts, stripes, colors, blocks = len(p) // 32, 2, 8, 2
    index = 0
    for part in range(parts):
        for block in range(blocks):
            for stripe in range(stripes):
                for color in range(colors):
                    pi = index + part*colors*stripes*blocks + block*colors + stripe*stripes*colors + color
                    out += p[pi*4:pi*4+4]
    return out

def _reswizzle_palette(linear):
    n = len(linear) // 4
    marker = bytearray(n * 4)
    for i in range(n):
        marker[i*4] = i % 256; marker[i*4+1] = i // 256
    unswizzled = _unswizzle_palette(bytes(marker))
    perm = [unswizzled[i*4] + unswizzled[i*4+1]*256 for i in range(n)]
    out = bytearray(len(linear))
    for i in range(n):
        out[perm[i]*4:perm[i]*4+4] = linear[i*4:i*4+4]
    return bytes(out)

def _unswizzle_psp_packed(w_bytes, h, data_in):
    out = bytearray(len(data_in))
    src = 0
    for yb in range(max(1, h >> 3)):
        for xb in range(max(1, w_bytes >> 4)):
            for row in range(8):
                dst = (yb*8 + row) * w_bytes + xb*16
                for col in range(16):
                    if src < len(data_in) and dst+col < len(out):
                        out[dst+col] = data_in[src]
                    src += 1
    return out

def _ps2_swizzle4_block(d):
    lut=[0,68,8,76,16,84,24,92,1,69,9,77,17,85,25,93,2,70,10,78,18,86,26,94,3,71,11,79,19,87,27,95,
         4,64,12,72,20,80,28,88,5,65,13,73,21,81,29,89,6,66,14,74,22,82,30,90,7,67,15,75,23,83,31,91,
         32,100,40,108,48,116,56,124,33,101,41,109,49,117,57,125,34,102,42,110,50,118,58,126,35,103,43,111,51,119,59,127,
         36,96,44,104,52,112,60,120,37,97,45,105,53,113,61,121,38,98,46,106,54,114,62,122,39,99,47,107,55,115,63,123,
         4,64,12,72,20,80,28,88,5,65,13,73,21,81,29,89,6,66,14,74,22,82,30,90,7,67,15,75,23,83,31,91,
         0,68,8,76,16,84,24,92,1,69,9,77,17,85,25,93,2,70,10,78,18,86,26,94,3,71,11,79,19,87,27,95,
         36,96,44,104,52,112,60,120,37,97,45,105,53,113,61,121,38,98,46,106,54,114,62,122,39,99,47,107,55,115,63,123,
         32,100,40,108,48,116,56,124,33,101,41,109,49,117,57,125,34,102,42,110,50,118,58,126,35,103,43,111,51,119,59,127]
    out=bytearray(256); i1=0; p=0
    for k in range(4):
        i0=(k%2)*128
        for i in range(16):
            for j in range(4):
                c=0
                for step in range(2):
                    a=lut[i0];i0+=1;i2=(a&1)*4
                    c_in=(d[p+a//2]&(0x0F<<i2))>>i2
                    if step==0: c|=c_in
                    else: c|=(c_in<<4)&0xF0
                out[i1]=c;i1+=1
        p+=64
    return bytes(out)

def _ps2_swizzle4_page(w,h,inp):
    bt4=[0,2,8,10,1,3,9,11,4,6,12,14,5,7,13,15,16,18,24,26,17,19,25,27,20,22,28,30,21,23,29,31]
    bt32=[0,1,4,5,16,17,20,21,2,3,6,7,18,19,22,23,8,9,12,13,24,25,28,29,10,11,14,15,26,27,30,31]
    out=bytearray(64*4*32); h32=[0]*32; v32=[0]*32; idx=0
    for i in range(4):
        for j in range(8): b=bt32[idx]; h32[b]=j; v32[b]=i; idx+=1
    nw=w//32; nh=h//16
    for i in range(nh):
        for j in range(nw):
            ib=bt4[i*nw+j]; po=bytearray(256)
            pi_off=16*i*(w//2)+j*16
            for k in range(16): po[k*16:k*16+16]=inp[pi_off+k*(w//2):pi_off+k*(w//2)+16]
            ob=_ps2_swizzle4_block(po)
            off=8*v32[ib]*256+h32[ib]*32
            for k in range(8): out[off+k*256:off+k*256+32]=ob[k*32:k*32+32]
    return bytes(out)

def _ps2_swizzle4(data, W, H):
    PW=128; PH=128; CPW=64; CPH=32
    out=bytearray(len(data)); npw=(W-1)//PW+1; nph=(H-1)//PH+1
    p4wb=PW//2; p32wb=CPW*4
    niw=H*2 if nph==1 else p32wb; noh=H if nph==1 else PH
    nih=W//4 if npw==1 else CPH; now=W//2 if npw==1 else p4wb
    for i in range(nph):
        for j in range(npw):
            pi_off=(now*noh)*npw*i+now*j
            ip=bytearray(PW//2*PH)
            for k in range(noh): s=k*now*npw+pi_off; ip[k*p4wb:k*p4wb+now]=data[s:s+now]
            op=_ps2_swizzle4_page(PW,PH,ip)
            po_off=(niw*nih)*npw*i+niw*j
            for k in range(nih): s=k*p32wb; d=po_off+k*niw*npw; out[d:d+niw]=op[s:s+niw]
    return bytes(out)

def _ps2_unswizzle4_block(d):
    lut=[0,8,16,24,32,40,48,56,2,10,18,26,34,42,50,58,4,12,20,28,36,44,52,60,6,14,22,30,38,46,54,62,
         64,72,80,88,96,104,112,120,66,74,82,90,98,106,114,122,68,76,84,92,100,108,116,124,70,78,86,94,102,110,118,126,
         33,41,49,57,1,9,17,25,35,43,51,59,3,11,19,27,37,45,53,61,5,13,21,29,39,47,55,63,7,15,23,31,
         97,105,113,121,65,73,81,89,99,107,115,123,67,75,83,91,101,109,117,125,69,77,85,93,103,111,119,127,71,79,87,95,
         32,40,48,56,0,8,16,24,34,42,50,58,2,10,18,26,36,44,52,60,4,12,20,28,38,46,54,62,6,14,22,30,
         96,104,112,120,64,72,80,88,98,106,114,122,66,74,82,90,100,108,116,124,68,76,84,92,102,110,118,126,70,78,86,94,
         1,9,17,25,33,41,49,57,3,11,19,27,35,43,51,59,5,13,21,29,37,45,53,61,7,15,23,31,39,47,55,63,
         65,73,81,89,97,105,113,121,67,75,83,91,99,107,115,123,69,77,85,93,101,109,117,125,71,79,87,95,103,111,119,127]
    out=bytearray(256); i1=0; p=0
    for k in range(4):
        i0=(k%2)*128
        for i in range(16):
            for j in range(4):
                a=lut[i0];i0+=1;c=((d[p+a//2])>>((a&1)*4))&0xF
                a=lut[i0];i0+=1;c|=(((d[p+a//2])>>((a&1)*4))&0xF)<<4
                out[i1]=c;i1+=1
        p+=64
    return bytes(out)

def _ps2_unswizzle4_page(w,h,inp):
    bt4=[0,2,8,10,1,3,9,11,4,6,12,14,5,7,13,15,16,18,24,26,17,19,25,27,20,22,28,30,21,23,29,31]
    bt32=[0,1,4,5,16,17,20,21,2,3,6,7,18,19,22,23,8,9,12,13,24,25,28,29,10,11,14,15,26,27,30,31]
    out=bytearray(64*4*32); h32=[0]*32; v32=[0]*32; idx=0
    for i in range(4):
        for j in range(8): b=bt32[idx]; h32[b]=j; v32[b]=i; idx+=1
    nw=w//32; nh=h//16
    for i in range(nh):
        for j in range(nw):
            ib=bt4[i*nw+j]; po=bytearray(256)
            off=8*v32[ib]*256+h32[ib]*32
            for k in range(8): po[k*32:(k+1)*32]=inp[off+k*256:off+k*256+32]
            ob=_ps2_unswizzle4_block(po)
            for k in range(16): s=(16*i*64)+j*16+k*64; out[s:s+16]=ob[k*16:k*16+16]
    return bytes(out)

def _ps2_unswizzle4(data, W, H):
    PW=128; PH=128; CPW=64; CPH=32
    out=bytearray(len(data)); npw=(W-1)//PW+1; nph=(H-1)//PH+1
    p4wb=PW//2; p32wb=CPW*4
    niw=H*2 if nph==1 else p32wb; noh=H if nph==1 else PH
    nih=W//4 if npw==1 else CPH; now=W//2 if npw==1 else p4wb
    for i in range(nph):
        for j in range(npw):
            off=(niw*nih)*npw*i+niw*j; po=data[off:]
            ip=bytearray(PW//2*PH)
            for k in range(nih): s=k*niw*npw; d=k*p32wb; ip[d:d+niw]=po[s:s+niw]
            op=_ps2_unswizzle4_page(PW,PH,ip)
            pi_off=(now*noh)*npw*i+now*j
            for k in range(noh): s=k*p4wb; d=pi_off+k*now*npw; out[d:d+now]=op[s:s+now]
    return bytes(out)

def _alpha_from_ps2(a): return min(255, round(a * 255 / 128))
def _alpha_to_ps2(a):   return min(128, round(a * 128 / 255))

# ── TDX → PNG ─────────────────────────────────────────────────────────────────
def tdx_to_png(tdx_path: str, out_path: str = None) -> str | None:
    data = open(tdx_path, 'rb').read()

    if len(data) < 0x61:
        print(f"  SKIP: file troppo corto")
        return None

    version = int.from_bytes(data[0x00:0x02], 'little')
    if version != 5:
        print(f"  SKIP: versione {version} non supportata")
        return None

    width      = int.from_bytes(data[0x04:0x06], 'little')
    height     = int.from_bytes(data[0x06:0x08], 'little')
    bpp        = data[0x08]
    pattern    = data[0x106] if len(data) > 0x106 else 0
    image_flags= int.from_bytes(data[0x02:0x04], 'little')
    is_dm      = (data[0x03] == 0x20)

    if width == 0 or height == 0:
        print(f"  SKIP: dimensioni {width}x{height}")
        return None

    min_size = width * height * (bpp // 8) if bpp >= 8 else (width * height) // 2
    if len(data) < min_size + 0x60:
        print(f"  SKIP: dati insufficienti")
        return None

    try:
        img = _decode(data, width, height, bpp, pattern, image_flags, is_dm)
    except Exception as e:
        print(f"  ERRORE: {e}")
        return None

    if img is None:
        print(f"  SKIP: formato non supportato ({bpp}bpp, flags=0x{image_flags:04X}, pat=0x{pattern:02X})")
        return None

    if not out_path:
        out_path = os.path.splitext(tdx_path)[0] + '.png'
    img.save(out_path, 'PNG')
    return out_path

def _decode(data, width, height, bpp, pattern, image_flags, is_dm):
    is_psp = bool(image_flags & 0x4000)
    if bpp == 32:
        if is_psp:
            raw = bytes(data[0x60:0x60+width*height*4])
            if len(raw) < width*height*4: return None
            unswizzled = _unswizzle_psp_packed(width*4, height, raw)
            rgba = bytearray()
            for i in range(width*height):
                r,g,b,a = unswizzled[i*4],unswizzled[i*4+1],unswizzled[i*4+2],unswizzled[i*4+3]
                rgba.extend([r,g,b,_alpha_from_ps2(a)])
            return Image.frombytes("RGBA", (width, height), bytes(rgba))
        else:
            expected = width * height * 4
            off = len(data) - expected
            if off < 0: return None
            raw = data[off:off+expected]
            rgba = bytearray()
            for i in range(width*height):
                r,g,b,a = raw[i*4],raw[i*4+1],raw[i*4+2],raw[i*4+3]
                rgba.extend([r,g,b,_alpha_from_ps2(a)])
            return Image.frombytes("RGBA", (width, height), bytes(rgba))

    if bpp == 24:
        expected = width * height * 3
        off = len(data) - expected
        if off < 0: return None
        return Image.frombytes("RGB", (width, height), bytes(data[off:off+expected]))

    if bpp == 8:
        if is_psp:
            pal_raw = data[0x60:0x60+1024]
            if len(pal_raw) < 1024: return None
            pix = bytearray(data[0x460:0x460+width*height])
            if len(pix) < width*height: pix.extend(b'\x00'*(width*height-len(pix)))
            pix = _unswizzle_psp_packed(width, height, pix)
        else:
            if pattern == 0x08: pal_off, pix_off = 0x1E0, 0x5E0
            elif pattern in (0x01, 0x02, 0x04): pal_off, pix_off = 0x160, 0x560
            else: return None
            pal_raw = data[pal_off:pal_off+1024]
            if len(pal_raw) < 1024: return None
            pal_raw = _unswizzle_palette(pal_raw)
            pix = bytearray(data[pix_off:pix_off+width*height])
            if len(pix) < width*height: pix.extend(b'\x00'*(width*height-len(pix)))
            if width >= 16 and height >= 16:
                pix = _unswizzle_i8(width, height, pix)

        return _build_rgba_indexed(pix, pal_raw, width, height)

    if bpp == 4:
        if is_psp:
            pal_raw = bytes(data[0x60:0x60+64]) + b'\x00'*(1024-64)
            packed  = bytes(data[0xA0:0xA0+(width*height)//2])
            if len(packed) < (width*height)//2:
                packed += b'\x00'*((width*height)//2-len(packed))
            img_dst_size = int.from_bytes(data[0x0E:0x10], 'little')
            if img_dst_size >= 0x200:
                unpacked = _unswizzle_psp_packed(width//2, height, packed)
            else:
                unpacked = packed
            pix = bytearray(n for b in unpacked for n in [b&0xF,(b>>4)&0xF])[:width*height]
        elif is_dm:
            pal_raw = bytes(data[0x160:0x160+64]) + b'\x00'*(1024-64)
            packed  = bytes(data[0x1A0:0x1A0+(width*height)//2])
            if len(packed) < (width*height)//2:
                packed += b'\x00'*((width*height)//2-len(packed))
            if image_flags == 0x2005:
                pix = bytearray(n for b in packed for n in [b&0xF,(b>>4)&0xF])
            else:
                result = _ps2_unswizzle4(packed, width, height)
                pix = bytearray(n for b in result for n in [b&0xF,(b>>4)&0xF])
            pix = pix[:width*height]
        else:
            if pattern == 0x08: pal_off, pix_off = 0x1E0, 0x5E0
            elif pattern in (0x01, 0x02, 0x04): pal_off, pix_off = 0x160, 0x560
            else: return None
            pal_raw = data[pal_off:pal_off+1024]
            if len(pal_raw) < 1024: return None
            packed = bytes(data[pix_off:pix_off+(width*height)//2])
            if len(packed) < (width*height)//2:
                packed += b'\x00'*((width*height)//2-len(packed))
            if pattern in (0x01, 0x04):
                i4 = _unswizzle_i4(width, height, packed)
                pix = bytearray(n for b in i4 for n in [b&0xF,(b>>4)&0xF])[:width*height]
            else:
                exp = bytearray(n for b in packed for n in [b&0xF,(b>>4)&0xF])
                pix = bytearray((idx&0x07)|((idx&0x08)<<1) for idx in exp)[:width*height]
                pal_raw = _unswizzle_palette(pal_raw)

        return _build_rgba_indexed(pix, pal_raw, width, height)
    return None

def _build_rgba_indexed(pix, pal_raw, w, h):
    rgb_pal = bytearray(); alpha_pal = []
    for i in range(256):
        r,g,b,a = pal_raw[i*4],pal_raw[i*4+1],pal_raw[i*4+2],pal_raw[i*4+3]
        rgb_pal.extend([r,g,b])
        alpha_pal.append(_alpha_from_ps2(a))
    pix = bytes(pix[:w*h])
    indexed = Image.new("P", (w, h))
    indexed.putdata(pix)
    indexed.putpalette(rgb_pal)
    conv = indexed.convert("RGBA")
    r,g,b,_ = conv.split()
    alpha_ch = Image.frombytes("L", (w,h), bytes(alpha_pal[idx] for idx in pix))
    return Image.merge("RGBA", (r,g,b,alpha_ch))

# ── PNG → TDX ─────────────────────────────────────────────────────────────────
def png_to_tdx(png_path: str, out_path: str = None) -> str | None:
    tdx_path = os.path.splitext(png_path)[0] + '.TDX'
    if not os.path.exists(tdx_path):
        tdx_path = os.path.splitext(png_path)[0] + '.tdx'
    if not os.path.exists(tdx_path):
        print(f"  ERRORE: nessun TDX originale trovato per {os.path.basename(png_path)}")
        return None

    tdx  = bytearray(open(tdx_path, 'rb').read())
    img  = Image.open(png_path).convert("RGBA")

    width      = int.from_bytes(tdx[0x04:0x06], 'little')
    height     = int.from_bytes(tdx[0x06:0x08], 'little')
    bpp        = tdx[0x08]
    pattern    = tdx[0x106] if len(tdx) > 0x106 else 0
    image_flags= int.from_bytes(tdx[0x02:0x04], 'little')
    is_dm      = (tdx[0x03] == 0x20)
    is_psp     = bool(image_flags & 0x4000)

    if img.size != (width, height):
        print(f"  AVVISO: ridimensiono PNG da {img.size} a {(width,height)}")
        img = img.resize((width, height))

    try:
        if is_psp:
            if bpp == 4: _inject_4bpp_psp(tdx, img, width, height)
            else: return None
        elif is_dm:
            if bpp == 4: _inject_4bpp_dm(tdx, img, width, height, image_flags)
            else: return None
        elif bpp == 32: _inject_32bpp(tdx, img, width, height)
        elif bpp == 24: _inject_24bpp(tdx, img, width, height)
        elif bpp == 8:  _inject_8bpp(tdx, img, width, height, pattern)
        elif bpp == 4:  _inject_4bpp(tdx, img, width, height, pattern)
        else: return None
    except Exception as e:
        print(f"  ERRORE: {e}")
        return None

    if not out_path:
        out_path = os.path.splitext(png_path)[0] + '.TDX'
    open(out_path, 'wb').write(tdx)
    return out_path

def _inject_32bpp(tdx, img, w, h):
    expected = w * h * 4
    off = len(tdx) - expected
    img = img.convert("RGBA")
    for i, (r,g,b,a) in enumerate(img.getdata()):
        tdx[off+i*4]=r; tdx[off+i*4+1]=g; tdx[off+i*4+2]=b; tdx[off+i*4+3]=_alpha_to_ps2(a)

def _inject_24bpp(tdx, img, w, h):
    expected = w * h * 3
    off = len(tdx) - expected
    img = img.convert("RGB")
    for i, (r,g,b) in enumerate(img.getdata()):
        tdx[off+i*3]=r; tdx[off+i*3+1]=g; tdx[off+i*3+2]=b

def _inject_8bpp(tdx, img, w, h, pattern):
    pal_off, pix_off = (0x1E0, 0x5E0) if pattern == 0x08 else (0x160, 0x560)
    pal_swizzled = bytes(tdx[pal_off:pal_off+1024])
    pal_linear   = _unswizzle_palette(pal_swizzled)
    colors = [(pal_linear[i*4],pal_linear[i*4+1],pal_linear[i*4+2],pal_linear[i*4+3]) for i in range(256)]
    img_rgba = img.convert("RGBA")
    pixels = list(img_rgba.getdata())
    indices = []
    for r,g,b,a in pixels:
        best_idx=0; best_dist=float('inf')
        for i,(cr,cg,cb,ca) in enumerate(colors):
            dist=(r-cr)**2+(g-cg)**2+(b-cb)**2
            if dist<best_dist: best_dist=dist; best_idx=i
        indices.append(best_idx)
    tdx[pix_off:pix_off+w*h] = _swizzle_i8(w, h, bytes(indices))

def _inject_4bpp_psp(tdx, img, w, h):
    pal_raw = bytes(tdx[0x60:0x60+64])
    colors = [(pal_raw[i*4],pal_raw[i*4+1],pal_raw[i*4+2],pal_raw[i*4+3]) for i in range(16)]
    img_rgba = img.convert("RGBA")
    pixels   = list(img_rgba.getdata())
    indices  = []
    for r,g,b,a in pixels:
        best_idx = 0; best_dist = float('inf')
        for i, (cr,cg,cb,ca) in enumerate(colors):
            dist = (r-cr)**2 + (g-cg)**2 + (b-cb)**2 + (a-ca)**2
            if dist < best_dist: best_dist = dist; best_idx = i
        indices.append(best_idx)

    img_dst_size = int.from_bytes(tdx[0x0E:0x10], 'little')
    packed_size  = (w * h) // 2

    if img_dst_size >= 0x200:
        nibbles = bytearray(packed_size)
        for i in range(0, w*h, 2):
            nibbles[i//2] = (indices[i] & 0xF) | ((indices[i+1] & 0xF) << 4)
        swizzled = bytearray(packed_size)
        dst = 0
        for yb in range(max(1, h >> 3)):
            for xb in range(max(1, (w//2) >> 4)):
                for row in range(8):
                    src = (yb*8+row)*(w//2) + xb*16
                    for col in range(16):
                        if dst < packed_size and src+col < len(nibbles):
                            swizzled[dst] = nibbles[src+col]
                        dst += 1
        tdx[0xA0:0xA0+packed_size] = swizzled
    else:
        packed = bytearray(packed_size)
        for i in range(0, w*h, 2):
            packed[i//2] = (indices[i] & 0xF) | ((indices[i+1] & 0xF) << 4)
        tdx[0xA0:0xA0+packed_size] = packed

def _inject_4bpp_dm(tdx, img, w, h, image_flags):
    pal_raw = bytes(tdx[0x160:0x160+64])
    colors  = [(pal_raw[i*4],pal_raw[i*4+1],pal_raw[i*4+2],pal_raw[i*4+3]) for i in range(16)]
    img_rgba = img.convert("RGBA")
    pixels   = list(img_rgba.getdata())
    indices  = []
    for r,g,b,a in pixels:
        best_idx  = 0; best_dist = float('inf')
        for i,(cr,cg,cb,ca) in enumerate(colors):
            dist = (r-cr)**2+(g-cg)**2+(b-cb)**2
            if dist < best_dist: best_dist=dist; best_idx=i
        indices.append(best_idx)

    packed_size = (w*h)//2
    if image_flags == 0x2005:
        packed = bytearray(packed_size)
        for i in range(0, w*h, 2):
            packed[i//2] = (indices[i]&0xF)|((indices[i+1]&0xF)<<4)
    else:
        nibbles = bytearray(packed_size)
        for i in range(0, w*h, 2):
            nibbles[i//2] = (indices[i]&0xF)|((indices[i+1]&0xF)<<4)
        packed = bytearray(_ps2_swizzle4(bytes(nibbles), w, h))
    tdx[0x1A0:0x1A0+packed_size] = packed

def _inject_4bpp(tdx, img, w, h, pattern):
    pal_off, pix_off = (0x1E0, 0x5E0) if pattern == 0x08 else (0x160, 0x560)
    pal_raw = bytes(tdx[pal_off:pal_off+1024])
    if pattern in (0x01, 0x04): pal_linear = pal_raw
    else: pal_linear = _unswizzle_palette(pal_raw)

    colors = [(pal_linear[i*4],pal_linear[i*4+1],pal_linear[i*4+2],pal_linear[i*4+3]) for i in range(16)]
    img_rgba = img.convert("RGBA")
    pixels = list(img_rgba.getdata())
    indices = []
    for r,g,b,a in pixels:
        best_idx=0; best_dist=float('inf')
        for i,(cr,cg,cb,ca) in enumerate(colors):
            dist=(r-cr)**2+(g-cg)**2+(b-cb)**2
            if dist<best_dist: best_dist=dist; best_idx=i
        indices.append(best_idx)

    if pattern in (0x01, 0x04):
        packed = _swizzle_i4(w, h, indices)
        tdx[pix_off:pix_off+(w*h)//2] = packed
    else:
        inv = [0]*24
        for i in range(16): inv[(i&0x07)|((i&0x08)<<1)] = i
        remapped = [inv[min(idx,23)] for idx in indices]
        packed = bytearray((w*h)//2)
        for i in range(0, w*h, 2):
            packed[i//2] = remapped[i] | (remapped[i+1] << 4)
        tdx[pix_off:pix_off+(w*h)//2] = packed

# ── Main / Interactive / Batch ────────────────────────────────────────────────
def psp_to_ps2(psp_path: str, ps2_template_path: str = None, out_path: str = None) -> str | None:
    psp_data = open(psp_path, 'rb').read()
    iflags   = int.from_bytes(psp_data[0x02:0x04], 'little')
    if not (iflags & 0x4000):
        print(f"  Non è un file PSP (imageFlags=0x{iflags:04X})")
        return None

    w   = int.from_bytes(psp_data[0x04:0x06], 'little')
    h   = int.from_bytes(psp_data[0x06:0x08], 'little')
    bpp = psp_data[0x08]

    img = _decode(psp_data, w, h, bpp, 0, iflags, False)
    if img is None:
        return None

    if ps2_template_path is None:
        print(f"  Trascina il TDX PS2 template ({w}x{h} {bpp}bpp):")
        try:
            ps2_template_path = input("  Path: ").strip().strip('"').strip("'")
        except:
            return None

    if not os.path.exists(ps2_template_path):
        print(f"  ERRORE: template non trovato ({ps2_template_path})")
        return None

    ps2_tmpl = bytearray(open(ps2_template_path, 'rb').read())
    tmpl_w   = int.from_bytes(ps2_tmpl[0x04:0x06], 'little')
    tmpl_h   = int.from_bytes(ps2_tmpl[0x06:0x08], 'little')
    tmpl_bpp = ps2_tmpl[0x08]

    if tmpl_w != w or tmpl_h != h or tmpl_bpp != bpp:
        print(f"  SKIP ({os.path.basename(psp_path)}): dim/bpp mismatch col template")
        return None

    pattern  = ps2_tmpl[0x106] if len(ps2_tmpl) > 0x106 else 0
    is_dm_tmpl = (ps2_tmpl[0x03] == 0x20)

    if bpp == 4:
        pal_psp = bytes(psp_data[0x60:0x60+64])
        pix_raw = bytes(psp_data[0xA0:0xA0+(w*h)//2])
        if len(pix_raw) < (w*h)//2: pix_raw += b'\x00'*((w*h)//2-len(pix_raw))
        img_dst_size = int.from_bytes(psp_data[0x0E:0x10],'little')
        if img_dst_size >= 0x200: unpacked = _unswizzle_psp_packed(w//2, h, pix_raw)
        else: unpacked = pix_raw
        indices = [n for b in unpacked for n in [b&0xF,(b>>4)&0xF]][:w*h]

        if is_dm_tmpl:
            ps2_tmpl[0x160:0x160+64] = pal_psp
            dm_flags = int.from_bytes(ps2_tmpl[0x02:0x04],'little')
            packed_size = (w*h)//2
            if dm_flags == 0x2005:
                packed = bytearray(packed_size)
                for i in range(0, w*h, 2): packed[i//2] = (indices[i]&0xF)|((indices[i+1]&0xF)<<4)
            else:
                nibbles = bytearray(packed_size)
                for i in range(0, w*h, 2): nibbles[i//2] = (indices[i]&0xF)|((indices[i+1]&0xF)<<4)
                packed = bytearray(_ps2_swizzle4(bytes(nibbles), w, h))
            ps2_tmpl[0x1A0:0x1A0+packed_size] = packed
        else:
            pal_off = 0x1E0 if pattern == 0x08 else 0x160
            pix_off = 0x5E0 if pattern == 0x08 else 0x560
            if pattern in (0x01, 0x04):
                ps2_tmpl[pal_off:pal_off+64]   = pal_psp
                ps2_tmpl[pal_off+64:pal_off+1024] = b'\x00'*(1024-64)
                ps2_tmpl[pix_off:pix_off+(w*h)//2] = _swizzle_i4(w, h, indices)
            else:
                pal_full = pal_psp + b'\x00'*(1024-64)
                ps2_tmpl[pal_off:pal_off+1024] = _reswizzle_palette(pal_full)
                inv = [0]*24
                for i in range(16): inv[(i&0x07)|((i&0x08)<<1)] = i
                remapped = [inv[min(idx,23)] for idx in indices]
                packed = bytearray((w*h)//2)
                for i in range(0, w*h, 2): packed[i//2] = remapped[i]|(remapped[i+1]<<4)
                ps2_tmpl[pix_off:pix_off+(w*h)//2] = packed
    elif bpp == 8:
        pal_psp  = bytes(psp_data[0x60:0x60+1024])
        pix_raw  = bytes(psp_data[0x460:0x460+w*h])
        if len(pix_raw) < w*h: pix_raw += b'\x00'*(w*h-len(pix_raw))
        indices  = list(_unswizzle_psp_packed(w, h, pix_raw))
        pal_off  = 0x1E0 if pattern == 0x08 else 0x160
        pix_off  = 0x5E0 if pattern == 0x08 else 0x560
        ps2_tmpl[pal_off:pal_off+1024] = _reswizzle_palette(pal_psp)
        ps2_tmpl[pix_off:pix_off+w*h]  = _swizzle_i8(w, h, bytes(indices))
    elif bpp == 32: _inject_32bpp(ps2_tmpl, img, w, h)
    elif bpp == 24: _inject_24bpp(ps2_tmpl, img, w, h)
    else: return None

    if not out_path:
        out_path = os.path.splitext(psp_path)[0] + '_PS2.TDX'
    open(out_path, 'wb').write(ps2_tmpl)
    return out_path

def ps2_to_psp(ps2_path: str, psp_template_path: str = None, out_path: str = None) -> str | None:
    ps2_data = open(ps2_path, 'rb').read()
    if len(ps2_data) < 0x61: return None

    iflags = int.from_bytes(ps2_data[0x02:0x04], 'little')
    if iflags & 0x4000: return None

    w      = int.from_bytes(ps2_data[0x04:0x06], 'little')
    h      = int.from_bytes(ps2_data[0x06:0x08], 'little')
    bpp    = ps2_data[0x08]
    pattern= ps2_data[0x106] if len(ps2_data) > 0x106 else 0
    is_dm  = (ps2_data[0x03] == 0x20)

    if psp_template_path is None:
        print(f"  Trascina il TDX PSP template ({w}x{h} {bpp}bpp):")
        try:
            psp_template_path = input("  Path: ").strip().strip('"').strip("'")
        except:
            return None

    if not os.path.exists(psp_template_path):
        print(f"  ERRORE: template non trovato ({psp_template_path})")
        return None

    psp_tmpl = bytearray(open(psp_template_path, 'rb').read())
    tmpl_w   = int.from_bytes(psp_tmpl[0x04:0x06], 'little')
    tmpl_h   = int.from_bytes(psp_tmpl[0x06:0x08], 'little')
    tmpl_bpp = psp_tmpl[0x08]
    tmpl_flags = int.from_bytes(psp_tmpl[0x02:0x04], 'little')

    if not (tmpl_flags & 0x4000) or tmpl_w != w or tmpl_h != h or tmpl_bpp != bpp:
        print(f"  SKIP ({os.path.basename(ps2_path)}): dim/bpp mismatch col template")
        return None

    if bpp == 4:
        if is_dm:
            pal_ps2 = bytes(ps2_data[0x160:0x160+64])
            packed  = bytes(ps2_data[0x1A0:0x1A0+(w*h)//2])
            if len(packed) < (w*h)//2: packed += b'\x00'*((w*h)//2-len(packed))
            if iflags == 0x2005: unpacked = packed
            else: unpacked = _ps2_unswizzle4(packed, w, h)
            indices = [n for b in unpacked for n in [b&0xF,(b>>4)&0xF]][:w*h]
        else:
            pal_off = 0x1E0 if pattern == 0x08 else 0x160
            pix_off = 0x5E0 if pattern == 0x08 else 0x560
            pal_raw = ps2_data[pal_off:pal_off+1024]
            packed  = bytes(ps2_data[pix_off:pix_off+(w*h)//2])
            if len(packed) < (w*h)//2: packed += b'\x00'*((w*h)//2-len(packed))
            if pattern in (0x01, 0x04):
                pal_ps2 = pal_raw[:64]
                i4 = _unswizzle_i4(w, h, packed)
                indices = [n for b in i4 for n in [b&0xF,(b>>4)&0xF]][:w*h]
            else:
                pal_ps2 = _unswizzle_palette(pal_raw)[:64]
                exp = [n for b in packed for n in [b&0xF,(b>>4)&0xF]]
                indices = [(idx&0x07)|((idx&0x08)<<1) for idx in exp][:w*h]

        psp_tmpl[0x60:0x60+64] = pal_ps2
        img_dst_size = int.from_bytes(psp_tmpl[0x0E:0x10], 'little')
        packed_size = (w*h)//2
        nibbles = bytearray(packed_size)
        for i in range(0, w*h, 2):
            nibbles[i//2] = (indices[i]&0xF)|((indices[i+1]&0xF)<<4)
        
        if img_dst_size >= 0x200:
            swizzled = bytearray(packed_size)
            dst = 0
            for yb in range(max(1, h >> 3)):
                for xb in range(max(1, (w//2) >> 4)):
                    for row in range(8):
                        src = (yb*8+row)*(w//2) + xb*16
                        for col in range(16):
                            if dst < packed_size and src+col < len(nibbles):
                                swizzled[dst] = nibbles[src+col]
                            dst += 1
            psp_tmpl[0xA0:0xA0+packed_size] = swizzled
        else:
            psp_tmpl[0xA0:0xA0+packed_size] = nibbles
    elif bpp == 8:
        pal_off = 0x1E0 if pattern == 0x08 else 0x160
        pix_off = 0x5E0 if pattern == 0x08 else 0x560
        pal_raw = ps2_data[pal_off:pal_off+1024]
        pal_ps2 = _unswizzle_palette(pal_raw)
        pix = bytearray(ps2_data[pix_off:pix_off+w*h])
        if len(pix) < w*h: pix.extend(b'\x00'*(w*h-len(pix)))
        if w >= 16 and h >= 16: indices = _unswizzle_i8(w, h, pix)
        else: indices = pix

        psp_tmpl[0x60:0x60+1024] = pal_ps2
        swizzled = bytearray(w*h)
        dst = 0
        for yb in range(max(1, h >> 3)):
            for xb in range(max(1, w >> 4)):
                for row in range(8):
                    src = (yb*8+row)*w + xb*16
                    for col in range(16):
                        if dst < len(swizzled) and src+col < len(indices):
                            swizzled[dst] = indices[src+col]
                        dst += 1
        psp_tmpl[0x460:0x460+w*h] = swizzled
    elif bpp == 32:
        expected = w*h*4
        off = len(ps2_data) - expected
        if off < 0: return None
        raw = ps2_data[off:off+expected]
        swizzled = bytearray(expected)
        dst = 0
        w_bytes = w * 4
        for yb in range(max(1, h >> 3)):
            for xb in range(max(1, w_bytes >> 4)):
                for row in range(8):
                    src = (yb*8+row)*w_bytes + xb*16
                    for col in range(16):
                        if dst < expected and src+col < len(raw): swizzled[dst] = raw[src+col]
                        dst += 1
        psp_tmpl[0x60:0x60+expected] = swizzled
    else: return None

    if not out_path:
        out_path = os.path.splitext(ps2_path)[0] + '_PSP.TDX'
    open(out_path, 'wb').write(psp_tmpl)
    return out_path

# ── LOGICA CARTELLA E NOMI ────────────────────────────────────────────────────
def _get_batch_out_path(src_path, out_dir, custom_name, index, suffix):
    """Costruisce il path del file gestendo la numerazione a lunghezza fissa prima dell'ultimo carattere."""
    if custom_name:
        last_char = custom_name[-1]
        prefix_part = custom_name[:-1]
        match = re.search(r'(\d+)$', prefix_part)
        if match:
            num_str = match.group(1)
            width = len(num_str)
            base_val = int(num_str)
            val = base_val + index
            prefix = prefix_part[:match.start(1)]
            name = f"{prefix}{val:0{width}d}{last_char}"
        else:
            name = custom_name + str(index)
    else:
        name = os.path.splitext(os.path.basename(src_path))[0]
    
    final_dir = out_dir if out_dir else os.path.dirname(src_path)
    if final_dir: 
        os.makedirs(final_dir, exist_ok=True)
    
    # Rimuove il suffisso _PS2 o _PSP se è stata impostata una cartella di destinazione
    if out_dir:
        if suffix.upper() in ('_PS2.TDX', '_PSP.TDX'):
            suffix = '.TDX'
            
    return os.path.join(final_dir, name + suffix)

def process_file(path):
    ext  = os.path.splitext(path)[1].lower()
    base = os.path.splitext(os.path.basename(path))[0]
    name = os.path.basename(path)

    if base.endswith('_PS2') or base.endswith('_PSP'): return

    if ext == '.tdx':
        data = open(path,'rb').read()
        iflags = int.from_bytes(data[0x02:0x04],'little') if len(data)>=4 else 0
        w_   = int.from_bytes(data[0x04:0x06],'little') if len(data)>=8 else 0
        h_   = int.from_bytes(data[0x06:0x08],'little') if len(data)>=8 else 0
        bpp_ = data[0x08] if len(data)>=9 else 0

        if iflags & 0x4000:
            print(f"PSP TDX: {name} (flags=0x{iflags:04X}, {w_}x{h_} {bpp_}bpp)")
            print(f"  [1] Converti in PNG")
            print(f"  [2] Converti in PS2 TDX (richiede template PS2)")
            try: scelta = input("  Scelta (1/2, default=1): ").strip()
            except: scelta = '1'
            if scelta == '2':
                out = psp_to_ps2(path)
                if out: print(f"  -> {os.path.basename(out)}")
            else:
                out = tdx_to_png(path)
                if out: print(f"  -> {os.path.basename(out)}")
        elif iflags != 0 and len(data) >= 0x61:
            print(f"PS2 TDX: {name} (flags=0x{iflags:04X}, {w_}x{h_} {bpp_}bpp)")
            print(f"  [1] Converti in PNG")
            print(f"  [2] Converti in PSP TDX (richiede template PSP)")
            try: scelta = input("  Scelta (1/2, default=1): ").strip()
            except: scelta = '1'
            if scelta == '2':
                out = ps2_to_psp(path)
                if out: print(f"  -> {os.path.basename(out)}")
            else:
                out = tdx_to_png(path)
                if out: print(f"  -> {os.path.basename(out)}")
        else:
            print(f"TDX->PNG: {name}")
            out = tdx_to_png(path)
            if out: print(f"  -> {os.path.basename(out)}")
    elif ext == '.png':
        print(f"PNG->TDX: {name}")
        out = png_to_tdx(path)
        if out: print(f"  -> {os.path.basename(out)}")

def batch_convert_to_png(folder, out_dir='', custom_name=''):
    valid_files = []
    for root, _, files in os.walk(folder):
        for f in files:
            if f.lower().endswith('.tdx') and not os.path.splitext(f)[0].endswith(('_PS2','_PSP')):
                valid_files.append(os.path.join(root, f))
    valid_files.sort()

    count = 0; skip = 0
    for i, path in enumerate(valid_files):
        out_path = _get_batch_out_path(path, out_dir, custom_name, i, '.png')
        if tdx_to_png(path, out_path): count += 1
        else: skip += 1
    print(f"\nBatch TDX->PNG completato: {count} convertiti, {skip} skippati")

def batch_ps2_to_psp(ps2_folder, psp_template_path, out_dir='', custom_name=''):
    if not os.path.isfile(psp_template_path):
        print(f"  ERRORE: Il template deve essere un file singolo ({psp_template_path})")
        return

    valid_files = []
    for root, _, files in os.walk(ps2_folder):
        for f in files:
            if f.lower().endswith('.tdx') and not os.path.splitext(f)[0].endswith(('_PS2','_PSP')):
                valid_files.append(os.path.join(root, f))
    valid_files.sort()

    count = 0; skip = 0
    for i, path in enumerate(valid_files):
        out_path = _get_batch_out_path(path, out_dir, custom_name, i, '_PSP.TDX')
        print(f"Elaborazione: {os.path.basename(path)} -> {os.path.basename(out_path)}")
        if ps2_to_psp(path, psp_template_path, out_path): count += 1
        else: skip += 1
    print(f"\nBatch PS2->PSP completato: {count} convertiti, {skip} falliti o ignorati")

def batch_psp_to_ps2(psp_folder, ps2_template_path, out_dir='', custom_name=''):
    if not os.path.isfile(ps2_template_path):
        print(f"  ERRORE: Il template deve essere un file singolo ({ps2_template_path})")
        return

    valid_files = []
    for root, _, files in os.walk(psp_folder):
        for f in files:
            if f.lower().endswith('.tdx') and not os.path.splitext(f)[0].endswith(('_PS2','_PSP')):
                valid_files.append(os.path.join(root, f))
    valid_files.sort()

    count = 0; skip = 0
    for i, path in enumerate(valid_files):
        out_path = _get_batch_out_path(path, out_dir, custom_name, i, '_PS2.TDX')
        print(f"Elaborazione: {os.path.basename(path)} -> {os.path.basename(out_path)}")
        if psp_to_ps2(path, ps2_template_path, out_path): count += 1
        else: skip += 1
    print(f"\nBatch PSP->PS2 completato: {count} convertiti, {skip} falliti o ignorati")

if __name__ == '__main__':
    args = [a for a in sys.argv[1:] if not a.startswith('--')]

    if '--batch-png' in sys.argv:
        idx = sys.argv.index('--batch-png')
        batch_convert_to_png(sys.argv[idx+1])
    elif '--batch-ps2-to-psp' in sys.argv:
        idx = sys.argv.index('--batch-ps2-to-psp')
        batch_ps2_to_psp(sys.argv[idx+1], sys.argv[idx+2])
    elif '--batch-psp-to-ps2' in sys.argv:
        idx = sys.argv.index('--batch-psp-to-ps2')
        batch_psp_to_ps2(sys.argv[idx+1], sys.argv[idx+2])
    elif args:
        for p in args:
            p = p.strip('"').strip("'")
            if os.path.isfile(p):
                process_file(p)
            elif os.path.isdir(p):
                batch_convert_to_png(p)
    else:
        print("SFTOS/DM/LS/PSP TDX Tool")
        print("Trascina file TDX/PNG, oppure un'intera CARTELLA.")
        print("Comandi batch: 'batch png <cartella>' | 'batch ps2->psp <cart_ps2> <file_tmpl_psp>' | 'batch psp->ps2 <cart_psp> <file_tmpl_ps2>'")
        while True:
            try:
                cmd = input('\nFile/cartella (o "exit"): ').strip().strip('"').strip("'")
            except (EOFError, KeyboardInterrupt):
                break
            if cmd.lower() == 'exit':
                break
            
            if cmd.lower().startswith('batch png '):
                folder = cmd[10:].strip().strip('"').strip("'")
                if os.path.isdir(folder): batch_convert_to_png(folder)
                else: print(f"Cartella non trovata: {folder}")
                continue
            
            if cmd.lower().startswith('batch ps2->psp '):
                args_str = cmd[15:].strip()
                parts = [p for p in args_str.split('"') if p.strip()]
                if len(parts) >= 2: batch_ps2_to_psp(parts[0].strip(), parts[1].strip())
                else: print('Uso: batch ps2->psp "<cart_ps2>" "<file_tmpl_psp>"')
                continue
                
            if cmd.lower().startswith('batch psp->ps2 '):
                args_str = cmd[15:].strip()
                parts = [p for p in args_str.split('"') if p.strip()]
                if len(parts) >= 2: batch_psp_to_ps2(parts[0].strip(), parts[1].strip())
                else: print('Uso: batch psp->ps2 "<cart_psp>" "<file_tmpl_ps2>"')
                continue
                
            if not cmd:
                paths = filedialog.askopenfilenames(
                    title='Seleziona file TDX o PNG',
                    filetypes=[('TDX/PNG','*.tdx *.TDX *.png *.PNG'),('Tutti','*.*')]
                )
                for p in paths: process_file(p)
            elif os.path.exists(cmd):
                if os.path.isdir(cmd):
                    print(f"\nCartella rilevata: {cmd}")
                    print("Scegli un'azione da applicare a TUTTI i file nella cartella:")
                    print("  [1] Estrai tutti come PNG")
                    print("  [2] Converti tutti da PSP -> PS2 (richiede UN template PS2)")
                    print("  [3] Converti tutti da PS2 -> PSP (richiede UN template PSP)")
                    try: scelta_dir = input("  Scelta (1/2/3, default=1): ").strip()
                    except: scelta_dir = '1'
                    
                    out_dir = input("  Cartella di destinazione (lascia vuoto per la stessa cartella): ").strip().strip('"').strip("'")
                    custom_name = input("  Nuovo nome base (lascia vuoto per mantenere originali, es. _PATC_BIG_R010): ").strip()
                    
                    if scelta_dir == '2':
                        tmpl = input("  Trascina il file TDX PS2 (SINGOLO TEMPLATE): ").strip().strip('"').strip("'")
                        batch_psp_to_ps2(cmd, tmpl, out_dir, custom_name)
                    elif scelta_dir == '3':
                        tmpl = input("  Trascina il file TDX PSP (SINGOLO TEMPLATE): ").strip().strip('"').strip("'")
                        batch_ps2_to_psp(cmd, tmpl, out_dir, custom_name)
                    else:
                        batch_convert_to_png(cmd, out_dir, custom_name)
                else:
                    process_file(cmd)
            else:
                print(f"Percorso non trovato: {cmd}")