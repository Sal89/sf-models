import os
from PIL import Image
import swizzle
from helpers import alpha_to_ps2

def inject_png_to_tdx(png_path, template_path):
    print(f"--- TDX Injector Starting ---")

    # 1. Load the developer-made template
    if not os.path.exists(template_path):
        print(f"Error: Template {template_path} not found.")
        return

    with open(template_path, 'rb') as f:
        data = bytearray(f.read())

    # Read the original developer settings
    width  = int.from_bytes(data[0x04:0x06], 'little')
    height = int.from_bytes(data[0x06:0x08], 'little')
    bpp    = data[0x08]
    pattern = data[0x106]

    print(f"Template Settings: {width}x{height}, {bpp}bpp, Swizzle Pattern {pattern}")

    # 2. Open the new image and force it to match the developer size
    img = Image.open(png_path).convert("RGBA").resize((width, height))
    num_colors = 256 if bpp == 8 else 16
    quantized = img.quantize(colors=num_colors, method=Image.FASTOCTREE)
    indices = list(quantized.getdata())
    raw_pal = quantized.getpalette()

    # BUGFIX: alpha_map non deterministico.
    # L'approccio precedente usava {indice_palette: alpha_pixel}, dove in caso di
    # collisione vinceva l'ultimo pixel incontrato — ordine dipendente dalla
    # quantizzazione, non riproducibile tra esecuzioni diverse.
    # Soluzione: per ogni indice di palette raccogliamo tutti i valori alpha dei
    # pixel che lo usano e ne facciamo la media (deterministica e rappresentativa).
    alpha_pixels = img.getdata()
    alpha_accum = [[] for _ in range(num_colors)]
    for i, idx in enumerate(indices):
        alpha_accum[idx].append(alpha_pixels[i][3])

    interleaved_pal = bytearray()
    for i in range(num_colors):
        interleaved_pal.extend(raw_pal[i*3 : i*3+3])
        avg_alpha = round(sum(alpha_accum[i]) / len(alpha_accum[i])) if alpha_accum[i] else 255
        interleaved_pal.append(alpha_to_ps2(avg_alpha))  # Scala PNG (0-255) -> PS2 (0-128)

    # 3. Process Swizzling based on Developer Pattern
    if pattern == 8:
        # Pattern 08: Palette at 0x1E0, Pixels at 0x5E0 (Both swizzled)
        pal_offset, pix_offset = 0x1E0, 0x5E0
        final_palette = swizzle.reswizzle_palette(bytes(interleaved_pal))
    else:
        # Pattern 01: Palette at 0x160, Pixels at 0x560
        pal_offset, pix_offset = 0x160, 0x560
        final_palette = bytes(interleaved_pal)

    print("Applying PS2 Swizzle...")
    if bpp == 8:
        final_pixels = swizzle.swizzle_i8(width, height, bytes(indices))
    else:
        final_pixels = swizzle.swizzle_i4(width, height, bytes(indices))

    # 4. Injection: Swap developer data for yours
    data[pal_offset : pal_offset + len(final_palette)] = final_palette
    data[pix_offset : pix_offset + len(final_pixels)] = final_pixels

    # Save the output file
    output_filename = "MODDED_" + os.path.basename(template_path)
    with open(output_filename, "wb") as f:
        f.write(data)

    print(f"Success! Created {output_filename}")
    print(f"Structure is now bit-perfect with {template_path}")

if __name__ == "__main__":
    # Change these names to match your files
    inject_png_to_tdx("_BOOT_2DR_CREA0.png", "_BOOT_2DR_CREA0.TDX")
