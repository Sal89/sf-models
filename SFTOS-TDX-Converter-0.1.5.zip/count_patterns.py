"""
Scansiona una cartella di file TDX e mostra la distribuzione di imageFlags/bpp.
Evidenzia le combinazioni non ancora documentate.
Uso: python count_patterns.py <cartella>
"""
import sys, os
from collections import Counter

# Combinazioni documentate e funzionanti
# (imageFlags_mask, bpp) — None = qualsiasi
KNOWN = {
    # Omega Strain PS2
    (0x0007, 4), (0x0007, 8), (0x0007, 24), (0x0007, 32),
    # Dark Mirror PS2
    (0x2001, 4), (0x2001, 8),
    (0x2005, 4),
    # Logan's Shadow PS2 / PSP con bit 0x4000
    (0x4000, 4), (0x4000, 8), (0x4000, 32),  # match su bit
    # Vuoti/placeholder
    (0x0000, 0),
}

def is_known(iflags, bpp):
    if bpp == 0: return True
    if iflags & 0x4000: return True   # tutti i PSP gestiti
    return (iflags, bpp) in KNOWN

def scan(folder):
    combos = Counter(); examples = {}; errors = []; total = 0

    for root, dirs, files in os.walk(folder):
        for f in sorted(files):
            if not f.lower().endswith('.tdx'): continue
            path = os.path.join(root, f)
            try:
                data = open(path,'rb').read()
                if len(data) < 0x0B: continue
                ver    = int.from_bytes(data[0x00:0x02],'little')
                iflags = int.from_bytes(data[0x02:0x04],'little')
                bpp    = data[0x08]
                key    = (iflags, bpp)
                combos[key] += 1
                if key not in examples: examples[key] = path
                total += 1
            except Exception as e:
                errors.append(f"{f}: {e}")

    known_n   = sum(v for k,v in combos.items() if is_known(*k))
    unknown_n = sum(v for k,v in combos.items() if not is_known(*k))

    print(f"Totale TDX: {total}  |  Noti: {known_n}  |  Da investigare: {unknown_n}")

    unknown = {k:v for k,v in combos.items() if not is_known(*k)}
    known   = {k:v for k,v in combos.items() if is_known(*k)}

    if unknown:
        print(f"\n⚠  NUOVI (ordine per frequenza):")
        for (fl,bpp), count in sorted(unknown.items(), key=lambda x:-x[1]):
            print(f"  flags=0x{fl:04X} {bpp}bpp: {count} file")
            print(f"    -> {examples[(fl,bpp)]}")
    else:
        print(f"\n✓ Nessuna combinazione nuova!")

    print(f"\nNoti (ordine per frequenza):")
    for (fl,bpp), count in sorted(known.items(), key=lambda x:-x[1]):
        print(f"  flags=0x{fl:04X} {bpp:2d}bpp: {count}")

    if errors:
        print(f"\nErrori: {len(errors)}")
        for e in errors[:5]: print(f"  {e}")

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Uso: python count_patterns.py <cartella>")
    else:
        scan(sys.argv[1])