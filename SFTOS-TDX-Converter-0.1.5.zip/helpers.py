import math
import sys
import os

def get_save_option() -> bool:
    return not '--dryrun' in sys.argv

def get_folder_mode() -> bool:
    return '--folder' in sys.argv

def get_palette(color_palette: bytes, mode: int) -> tuple[bytearray, bytearray]:
    rgb_array = bytearray()
    alpha_array = bytearray()

    # Per 4bpp la palette occupa comunque 256 entry nel file PS2,
    # con i 16 colori reali distribuiti nelle posizioni 0-7 e 16-23
    # dopo unswizzle_palette. Leggiamo sempre 256 entry.
    palette_size = 256

    # Color data is stored RGBA, little endian
    for color_entry in range(palette_size):
        r = color_palette[color_entry * 4]
        g = color_palette[color_entry * 4 + 1]
        b = color_palette[color_entry * 4 + 2]
        a = color_palette[color_entry * 4 + 3]

        rgb_array.extend([r,g,b])
        alpha_array.append(alpha_from_ps2(a))

    return rgb_array, alpha_array

def convert_to_8bpp(pixel_data: bytes) -> bytearray:
    converted_8bpp = bytearray()
    for pixel in pixel_data:
        first_pixel = (pixel >> 4) & 0x0F
        second_pixel = pixel & 0x0F
        converted_8bpp.append(second_pixel)
        converted_8bpp.append(first_pixel)
    return converted_8bpp

def pad_bytes(bytes_in: bytes, pad_length: int) -> bytes:
    array = bytearray(bytes_in)
    array.extend(b'\x00' * pad_length)
    return array

def alpha_to_ps2(a: int) -> int:
    """Converte un valore alpha PNG (0-255) nella scala PS2 (0-128).
    La PS2 usa 0x80 (128) come opacità piena, non 0xFF (255).
    Valori intermedi vanno scalati di conseguenza."""
    return min(128, round(a * 128 / 255))

def alpha_from_ps2(a: int) -> int:
    """Converte un valore alpha PS2 (0-128) nella scala PNG (0-255)."""
    return min(255, round(a * 255 / 128))

def scan_folders(folder_path: str) -> list[str]:
    file_list = []

    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.lower().endswith(".tdx"):
                full_path = os.path.join(root, file)
                file_list.append(full_path)

    return file_list

def pack_palette(image_palette, alpha_data) -> bytes:
    # image_palette is a list of [R, G, B, R, G, B...]
    # alpha_data is a list of [A, A, A...] in PNG scale (0-255)
    packed = bytearray()
    for i in range(len(alpha_data)):
        packed.append(image_palette[i*3])
        packed.append(image_palette[i*3 + 1])
        packed.append(image_palette[i*3 + 2])
        packed.append(alpha_to_ps2(alpha_data[i]))  # Converti in scala PS2 (0-128)
    return bytes(packed)